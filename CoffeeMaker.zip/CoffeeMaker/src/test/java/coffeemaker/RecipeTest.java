package coffeemaker;

public class RecipeTest {
}
